#ifdef CAPSHDOC
#error "don't include this twice"
#endif
#define CAPSHDOC

extern const char **explanations[];
extern const int capsh_doc_limit;
